package example;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.springframework.web.servlet.ModelAndView;

import Servion.CheckList;

public class Invoice extends TagSupport 
{

	
	@Override
	public int doEndTag() throws JspException
	{
		
		ModelAndView mdlv=new ModelAndView();
		HttpSession session=pageContext.getSession();
		JspWriter out=pageContext.getOut();
		// Enumeration<String> e=session.getAttributeNames();
		 int count=1;
		 CheckList c=new CheckList();
		 ArrayList<String> items=new ArrayList<>();
		
		 items=c.display();
		 mdlv.addObject("items",items);
		 
		// while(e.hasMoreElements())
	//	 {
		 	//String attributename=e.nextElement();
		 	//String attributevalue=session.getAttribute(attributename).toString();
	 	try 
		 	{
		 		//if(attributename.equalsIgnoreCase("username") || attributename.equals("rb"))
		 		//{
		 			
		 		//}
		 		//else
		 		//{	
	 	    Iterator itr = items.iterator();
	 	      
	 	      while(itr.hasNext()) {
	 	         Object element = itr.next();
	 	         System.out.println("Choosen items:"+element);
	 	       //  String pic="/resources/images/element";
	 	     out.println("<img src=\"<c:url value=\"\\resources\\images\\Apple.png\"/>\"/>");
	 	     //   out.println("<img src="<c:url value="/resources/element/.png>"/>") );
	 	         out.println(element);
	 	         out.println("<br><br>");
	 	      }
	 		
	 		
	 		
		 		
		 } catch (Exception e1) {}
		
	//	 }
		return super.doEndTag();
	}
}


