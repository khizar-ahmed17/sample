package onetomany;

import hiberproj.HiberUtility;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;


public class OneToManyClient {

	public static void main(String[] args) {
		
	

		
	
		
		Session session1=HiberUtility.getSession();
		
		Criteria cr=session1.createCriteria(Employee.class,"emp");
		cr.createAlias("emp.addresses", "ad");
		cr.add(Restrictions.eq("ad.city", "chennai"));			
		List<Employee> ad=cr.list();
		
		System.out.println(ad.get(0).getEmp_name());
		
		
		
		Query q=session1.createQuery("From onetomany.Employee");
		
		List<Employee> results = q.list();
		
		Iterator<Employee> it=results.iterator();
		
		Set<Address> se=it.next().getAddresses();
		
		Iterator<Address> ads=se.iterator();
		
		while (ads.hasNext()) {
			Address a=ads.next();
			
			System.out.println(a.getCity());
		
			
		}
		
		
		
		
		
		
	}
}
