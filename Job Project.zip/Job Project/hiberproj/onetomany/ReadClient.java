package onetomany;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.classic.Session;

import hiberproj.HiberUtility;

public class ReadClient {
public static void main(String[] args) throws Exception {
	Session session=HiberUtility.getSession();
	Employee emp=(Employee)session.get(Employee.class,100);
	Set<Address> set=emp.getAddresses();
	Iterator<Address> iter=set.iterator();
	Address dela=null;
	while(iter.hasNext())
	{
	Address a=iter.next();
	if(a.getCity().equals("bangalore"))
	{
		dela=a;
	}
	}
	emp.getAddresses().remove(dela);
	session.update(emp);
	HiberUtility.closeSession(null);
	
}
}
