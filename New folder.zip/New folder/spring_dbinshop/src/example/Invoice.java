package example;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import Servion.CheckList;

public class Invoice extends TagSupport 
{

	
	@Override
	public int doEndTag() throws JspException
	{
		
		
		HttpSession session=pageContext.getSession();
		JspWriter out=pageContext.getOut();
		// Enumeration<String> e=session.getAttributeNames();
		 int count=1;
		 CheckList c=new CheckList();
		 ArrayList<String> items=new ArrayList<>();
		 items=c.display();
		 
		// while(e.hasMoreElements())
	//	 {
		 	//String attributename=e.nextElement();
		 	//String attributevalue=session.getAttribute(attributename).toString();
	 	try 
		 	{
		 		//if(attributename.equalsIgnoreCase("username") || attributename.equals("rb"))
		 		//{
		 			
		 		//}
		 		//else
		 		//{	
	 	    Iterator itr = items.iterator();
	 	      
	 	      while(itr.hasNext()) {
	 	         Object element = itr.next();
	 	         out.println(element);
	 	         out.println("<br><br>");
	 	      }
	 		
	 		
	 		
		 		
		 } catch (Exception e1) {}
		
	//	 }
		return super.doEndTag();
	}
}


