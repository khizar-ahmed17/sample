package Servion;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("checkout")
public class CheckoutController 
{
	
	
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		
		ModelAndView mdlvie=new ModelAndView();
		mdlvie.setViewName("welcome");
		return mdlvie;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView logoutAction(HttpSession session)
	{
		UserBean userbean=new UserBean();
		CheckList ch=new CheckList();
		ch.remove();
		ModelAndView mdl=new ModelAndView();
		mdl.setViewName("welcome");
		mdl.addObject("userbean",userbean);
		return mdl;
	}
	
	
}
