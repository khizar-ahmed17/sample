package Servion;

import java.util.ArrayList;

public class CheckList 
{
	public static ArrayList<String> al=new ArrayList<>();
	
	public boolean add(String s)
	{
		al.add(s);
		return true;
	}
	public boolean remove()
	{
		al.clear();
		return true;
	}
	public ArrayList<String> display()
	{
		
		return al;
	}

}
