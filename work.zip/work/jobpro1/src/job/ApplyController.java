package job;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestapply")
public class ApplyController
{
	@Autowired
	ServiceProvider providerbean;
	
	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}

	@Autowired
	Jobs jobbean;
	
	public Jobs getJobbean() {
		return jobbean;
	}

	public void setJobbean(Jobs jobbean) {
		this.jobbean = jobbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(Jobs jobbean,ServiceRequester requestbean,HttpSession session)
	{
	String i=(String) session.getAttribute("username");
		
		System.out.println(i);
		if(i==null)
		{
			ServiceProvider userbean=new ServiceProvider();
			ModelAndView mdlvie=new ModelAndView();
			mdlvie.setViewName("login");
			mdlvie.addObject("userbean",userbean);
			
			mdlvie.addObject("requestbean",requestbean);
			
			return mdlvie;
		}
		else
		{
		
		
		
			System.out.println("In Get method of ApplyControl");
			int getspid=0;
			int reqid = 0;
			
			String uname=session.getAttribute("username").toString().trim();
			
			System.out.println("Session username:"+uname);
			Session session1=(Session)SessionUtility.GetSessionConnection();
			  Criteria criteria = session1.createCriteria(ServiceRequester.class);
			   
              criteria.add(Restrictions.eq("rq_username",uname));
              ServiceRequester requester = (ServiceRequester) criteria.uniqueResult();
              if (requester!=null) 
              {
            	  System.out.println("Requestid Found");
            	  reqid=requester.getRq_id();
                  System.out.println(requester.getRq_id() + " - " + requester.getRq_name());
  
              }
			
			String reqjobname=null;
			
			System.out.println("name:"+requestbean.getRq_name());
			ModelAndView mdlv=new ModelAndView();
			System.out.println("Reqid:"+reqid);
			System.out.println("Job name:"+jobbean.getCheckjobs());
			System.out.println(jobbean.getProduct());
			for (String s  : jobbean.getProduct()) {
				//session.setAttribute(s.toString().trim(),s.toString().trim());
				System.out.println("checked job name:"+s);
				reqjobname=s;
				
				}
			
		
			String hql = "FROM job.Jobs where job_name = :jobname";
			
			Query query = session1.createQuery(hql);
			query.setString("jobname",reqjobname);
			
			

			
			
			@SuppressWarnings("unchecked")
			List<Jobs> results = query.list();
			System.out.println(results);
			Iterator<Jobs> it=results.iterator();
			
			if (it.hasNext())
			{
				getspid=it.next().getSpobj().getSp_id();
				System.out.println("ServiceProviderID: "+getspid);
				
				//updating the applyrequest to reqid value
			}
			
				String hql1 = "FROM job.ServiceProvider where sp_id = :spid";
				//Query query1 = session1.createQuery(hql1);
				Query query1 = session1.createQuery(hql1);
				query1.setInteger("spid", getspid);
				@SuppressWarnings("unchecked")
				List<ServiceProvider> results1 = query1.list();
				System.out.println(results1);
				Iterator<ServiceProvider> iter=results1.iterator();
				
				
				
//				List<ServiceProvider> apply;
//				apply.add(getProviderbean());
				
				if(iter.hasNext())
				{
					System.out.println("Am here at last");
					iter.next().setApply_request(1);
					System.out.println("updated");
					//session1.save(hql);
					SessionUtility.closeSession(null);
				}
						
//			ServiceProvider providerbean=new ServiceProvider();
//			Session session=(Session)SessionUtility.GetSessionConnection();
//			String hql = "FROM job.ServiceProvider";
//			Query query = session.createQuery(hql);
//			List<ServiceProvider> results = query.list();
//			Iterator<ServiceProvider> it=results.iterator();
//			it.next().setApply_request(1);
			mdlv.setViewName("inindex");
			mdlv.addObject("jobbean",jobbean);
			mdlv.addObject("providerbean",providerbean);
			
			//SessionUtility.closeSession(null);
			return mdlv;
		
		}
	}
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView nextposition(Jobs jobbean)
	{
		System.out.println("In post method of Appply control");
		System.out.println("Am here");
		ModelAndView md=new ModelAndView();
		
		
	//	md.addObject("positions",results);
		md.addObject("jobbean",jobbean);
		md.setViewName("index");
		return md;
		
	}
	
	
}
