package job;



import java.util.Set;

import javax.persistence.GeneratedValue;

import org.springframework.stereotype.Controller;

@Controller
public class ServiceProvider 
{	
	@GeneratedValue
	private int sp_id;
	private String sp_username;
	private String sp_password;
	private String sp_email;
	private String sp_website;
	private String sp_address;
	private int apply_request;
	private int sp_status;
	private String product[];
	
	private Set<Jobs> jobs;
	
	public Set<Jobs> getJobs() {
		return jobs;
	}
	public void setJobs(Set<Jobs> jobs) {
		this.jobs = jobs;
	}
	public int getSp_id() {
		return sp_id;
	}
	public void setSp_id(int sp_id) {
		this.sp_id = sp_id;
	}
	public String getSp_username() {
		return sp_username;
	}
	public void setSp_username(String sp_username) {
		this.sp_username = sp_username;
	}
	public String getSp_password() {
		return sp_password;
	}
	public void setSp_password(String sp_password) {
		this.sp_password = sp_password;
	}
	public String getSp_email() {
		return sp_email;
	}
	public void setSp_email(String sp_email) {
		this.sp_email = sp_email;
	}
	public String getSp_website() {
		return sp_website;
	}
	public void setSp_website(String sp_website) {
		this.sp_website = sp_website;
	}
	public String getSp_address() {
		return sp_address;
	}
	public void setSp_address(String sp_address) {
		this.sp_address = sp_address;
	}
	/**
	 * @return the sp_status
	 */
	/**
	 * @return the sp_status
	 */
	public int getSp_status() {
		return sp_status;
	}
	/**
	 * @param sp_status the sp_status to set
	 */
	public void setSp_status(int sp_status) {
		this.sp_status = sp_status;
	}
	public int getApply_request() {
		return apply_request;
	}
	public void setApply_request(int apply_request) {
		this.apply_request = apply_request;
	}
	public String[] getProduct() {
		return product;
	}
	public void setProduct(String product[]) {
		this.product = product;
	}





	
}
