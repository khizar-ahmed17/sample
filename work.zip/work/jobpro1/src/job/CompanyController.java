package job;

import java.util.Iterator;

//This Method is used to retrieve the name of the Company who has posted for jobs

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("requestallcompany")
public class CompanyController
{
	@Autowired
	ServiceProvider providerbean;


	public ServiceProvider getProviderbean() {
		return providerbean;
	}

	public void setProviderbean(ServiceProvider providerbean) {
		this.providerbean = providerbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView movetoposition(ServiceProvider providerbean,HttpSession session)
	{
			System.out.println("In Get method of Specialization");
			ModelAndView mdlv=new ModelAndView();
			Session session1=(Session)SessionUtility.GetSessionConnection();
			Criteria cr = session1.createCriteria(ServiceProvider.class)
				    .setProjection(Projections.projectionList()
				      .add(Projections.property("sp_username"), "sp_username"))
				    .setResultTransformer(Transformers.aliasToBean(ServiceProvider.class));

				  List<ServiceProvider> ad = cr.list();
				  Iterator<ServiceProvider> it=ad.iterator();
			  while(it.hasNext())
			  	{
				  System.out.println(it.next().getSp_username());
				 
			  	}	
			
			mdlv.addObject("allcompany",ad);
			System.out.println("Object added Successfully");
			mdlv.addObject("providerbean",providerbean);
			
			String i=(String) session.getAttribute("username");
			
			System.out.println(i);
			if(i==null)
			{
			mdlv.setViewName("requestallcompany");
			}
			else
			{
				mdlv.setViewName("inrequestallcompany");
			}
			
			
			return mdlv;
		
		}
	
//	@RequestMapping(method=RequestMethod.POST)
//	public ModelAndView nextposition(ServiceProvider providerbean)
//	{
//		ModelAndView md=new ModelAndView();
//		Session session1=(Session)SessionUtility.GetSessionConnection();
////		Criteria cr=session1.createCriteria(ServiceRequester.class,"ser");
////		cr.createAlias("ser.jobs", "ad");
////		cr.add(Restrictions.eq("ad.job_specialization","Java"));	
////		List<ServiceRequester> results=cr.list();
////		Iterator<ServiceRequester> iter=results.iterator();
////		if(iter.hasNext())
////		{
////			System.out.println(iter.next().getRq_name());
////		}
//		
//		Criteria cr = session1.createCriteria(ServiceProvider.class)
//			    .setProjection(Projections.projectionList()
//			      .add(Projections.property("sp_username"), "sp_username"))
//			    .setResultTransformer(Transformers.aliasToBean(ServiceProvider.class));
//
//			  List<ServiceProvider> ad = cr.list();
//			  Iterator<ServiceProvider> it=ad.iterator();
//		  while(it.hasNext())
//		  	{
//			  System.out.println(it.next().getSp_username());
//			 
//		  	}	
//		
//		md.addObject("allcompany",ad);
//		System.out.println("Object added Successfully");
//		md.addObject("providerbean",providerbean);
//		md.setViewName("requestallcompany");
//		return md;
//		
//	}
	
	
	
	
}
