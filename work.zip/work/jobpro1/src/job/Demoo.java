package job;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.web.servlet.ModelAndView;

public class Demoo 
{
	public static void main(String[] args) 
	{
		
		/*
		
		Session session1=(Session)SessionUtility.GetSessionConnection();
		Criteria cr = session1.createCriteria(ServiceProvider.class)
			    .setProjection(Projections.projectionList()
			      .add(Projections.property("sp_username"), "sp_username"))
			    .setResultTransformer(Transformers.aliasToBean(ServiceProvider.class));

			  List<ServiceProvider> list = cr.list();
			  Iterator<ServiceProvider> iter=list.iterator();
		  while(iter.hasNext())
		  	{
			  System.out.println(iter.next().getSp_username());
			 
		  	}	
		  	*/
		
		
		/*
		
		Session session1=(Session)SessionUtility.GetSessionConnection();
		Query q=session1.createQuery("From job.ServiceProvider");
		
		List<ServiceProvider> results = q.list();
		
		Iterator<ServiceProvider> itr=results.iterator();
		
		Set<Jobs> se=itr.next().getJobs();
		
		Iterator<Jobs> ads=se.iterator();
		
		while (ads.hasNext()) {
			
			
			System.out.println(ads.next().getJob_name());
				
		}
		
	*/
		
		Session session=(Session)SessionUtility.GetSessionConnection();
//		ModelAndView md=new ModelAndView();
//		Criteria cr = session.createCriteria(Jobs.class)
//			    .setProjection(Projections.projectionList()
//			      .add(Projections.property("job_name"), "job_name")
//			      .add(Projections.property("job_specialization"), "job_specialization"))
//			    .setResultTransformer(Transformers.aliasToBean(Jobs.class));
//
//		  List<Jobs> list = cr.list();
//		  System.out.println(list);
//		
//		
//		
//		  String employeeName = (String) session.createQuery
//				  ("select empMaster.name from EmployeeMaster empMaster where empMaster.id = :id").setInteger("id",10).uniqueResult();
		
	/*	
		
		  String jobid
		  = 
		  (String) session.createQuery("select job_id from Jobs where job_specialization = :job_specialization").
		  setParameter("job_specialization","dot net").uniqueResult().toString();
	
		System.out.println(jobid);
		*/
		
		
//		Condition to get the name of the Company who has posted a particular job
		Session session1=(Session)SessionUtility.GetSessionConnection();
		
		Criteria cr=session1.createCriteria(ServiceProvider.class,"ser");
		cr.createAlias("ser.jobs", "ad");
		cr.add(Restrictions.eq("ad.job_name","java developer"));	
		List<ServiceProvider> ad=cr.list();
		Iterator<ServiceProvider> it=ad.iterator();
		System.out.println(ad);
		while(it.hasNext())
		{
			System.out.println("in loop");
			System.out.println(it.next().getSp_username());
			
		}
		//System.out.println("what am i"+ad.get(0).getRq_username());
		
		
	
		
		
		
		
		
		
		
		
		
		
		
	}
}
