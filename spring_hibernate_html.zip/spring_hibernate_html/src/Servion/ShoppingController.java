package Servion;



import java.util.List;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import org.dom4j.Visitor;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("shopping")
public class ShoppingController 

{
	int count=1;

	Session session=SessionUtility.GetSessionConnection();

	@Autowired
	UserBean userbean;
	
	public UserBean getUserbean() {
		return userbean;
	}

	public void setUserbean(UserBean userbean) {
		this.userbean = userbean;
	}
	
	@Autowired
	ProductBean pbean;

	public ProductBean getPbean() {
		return pbean;
	}

	public void setPbean(ProductBean pbean) {
		this.pbean = pbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView moveShoppingPage()
	{
		
		count=1;
		
		ModelAndView mandv=new ModelAndView();
		ProductBean pbean=new ProductBean();
		System.out.println(mandv.getViewName());
		System.out.println(pbean.getPage());
		
		
		String category="fruits";
		String hql = "FROM Product where category=:category";
		
		Query query = session.createQuery(hql);
		query.setParameter("category",category);
		@SuppressWarnings("unchecked")
		List<Product> results = query.list();
		
		
		mandv.setViewName("Shop1");
		mandv.addObject("pbean",pbean);
		mandv.addObject("products",results);
		count++;
		
		return mandv;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView shoppingproduct(ProductBean pbean,HttpSession session)
	{
		
		ModelAndView mandv=new ModelAndView();
		System.out.println(count);
		if(count==2)
		{
			String category="liquids";
			String hql = "FROM Product where category=:category";
			Session session1=SessionUtility.GetSessionConnection();
			
			Query query =session1.createQuery(hql);
			query.setParameter("category",category);
			@SuppressWarnings("unchecked")
			List<Product> results = query.list();
		
		if(pbean.getP1()!=null)session.setAttribute(pbean.getP1(),pbean.getP1());
		if(pbean.getP2()!=null)session.setAttribute(pbean.getP2(),pbean.getP2());
		if(pbean.getP3()!=null)session.setAttribute(pbean.getP3(),pbean.getP3());
		
		
		mandv.addObject("pbean",pbean);
		mandv.addObject("products",results);
		mandv.setViewName(pbean.getPage());
		count++;
		
		
		return mandv;
		}
		else if(count==3)
		{
			String category="natural";
			String hql = "FROM Product where category=:category";
			Session session1=SessionUtility.GetSessionConnection();
			
			Query query =session1.createQuery(hql);
			query.setParameter("category",category);
			@SuppressWarnings("unchecked")
			List<Product> results = query.list();
		
		if(pbean.getP1()!=null)session.setAttribute(pbean.getP1(),pbean.getP1());
		if(pbean.getP2()!=null)session.setAttribute(pbean.getP2(),pbean.getP2());
		if(pbean.getP3()!=null)session.setAttribute(pbean.getP3(),pbean.getP3());
		
		
		mandv.addObject("pbean",pbean);
		mandv.addObject("products",results);
		mandv.setViewName(pbean.getPage());
		
		
		return mandv;
		}
	return mandv;
	}
	
	
}
